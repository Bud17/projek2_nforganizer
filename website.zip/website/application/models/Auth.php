<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_models extends CI_Model {
    public function __construct() {
		perent::__construct();
	}
}