<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class V_model extends CI_Model {

    private $table = "jenis_kegiatan";

    public function getAll() { 
        // SELECT * from jenis_kegiatan
        $query = $this->db->get('jenis_kegiatan');
        return $query->result();
    }

    public function findById($id) {
        // SELECT * from jenis_kegiatan WHERE id =
        $this->db->where("id", $id);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function save($data){
        // Untuk menambahkan isi table
        $sql = "INSERT INTO faskes 
        (nama,alamat,latlong,jenis_id,deskripsi,skor_rating,kecamatan_id,website,jumlah_dokter,jumlah_pegawai)
          VALUES (?,?,?,?,?,?,?,?,?,?)";
       $this->db->query($sql,$data);

    }

    public function update($data){
        // Untuk edit data dalam tabel dengan klausa where
        $sql = "UPDATE faskes SET nama=?,latlong=?,jenis_id=?,deskripsi=?,
        skor_rating=?,kecamatan_id=?,website=?,jumlah_dokter=?,jumlah_pegawai=? WHERE id=?";
         $this->db->query($sql,$data);
    }

    public function delete($id){
        // Untuk menghapus data dalam tabel
        $sql = "delete from faskes where id=?";
        $this->db->query($sql,array($id));
    }
}