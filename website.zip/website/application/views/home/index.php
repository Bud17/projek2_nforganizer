<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- META DATA -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		
		

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i,900,900i" rel="stylesheet">
		
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
		
		<link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900" rel="stylesheet">
		
        <!-- TITLE OF SITE -->
        <title>NF Organizer</title>

        <!-- for title img -->
		<link rel="shortcut icon" type="image/icon" href="<?php echo base_url ("assets/images/logo/favicon.png")?>"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/font-awesome.min.css")?>">
		
		<!--linear icon css-->
		<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
		
		<!--animate.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/animate.css")?>">
		
		<!--hover.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/hover-min.css")?>">
		
		<!--vedio player css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/magnific-popup.css")?>">

		<!--owl.carousel.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/owl.carousel.min.css")?>">
		<link href="<?php echo base_url ("assets/css/owl.theme.default.min.css")?>" rel="stylesheet"/>


        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/bootstrap.min.css")?>">
		
		<!-- bootsnav -->
		<link href="<?php echo base_url ("assets/css/bootsnav.css")?>" rel="stylesheet"/>	
        
        <!--style.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/style.css")?>">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/responsive.css")?>">

    </head>
	
	<body>
		<!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

		
		
		
		<!--header start-->
		<section class="header">
			<div class="container">	
				<div class="header-left">
					<ul class="pull-left">
						<li>
							<a href="#">
								<i class="fa fa-phone" aria-hidden="true"></i> +6285 77722 7672
							</a>
						</li><!--/li-->
						<li>
							<a href="#">
								<i class="fa fa-envelope" aria-hidden="true"></i>nforganizer@gmail.com
							</a>
						</li><!--/li-->
					</ul><!--/ul-->
				</div><!--/.header-left -->
				<div class="header-right pull-right">
					<ul>
						<li class="reg">
							<a href="<?php echo base_url('index.php/c_registrasi/registrasi')?>" data-toggle="modal" >
								Register
							</a>
								/
							<a href="<?php echo base_url('index.php/login')?>" data-toggle="modal" >
								Log in
							</a>
							
							<!-- small modal -->
							<!-- <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
								<div class="modal-dialog modal-sm" role="document">
									<div class="modal-content">
										<div class="modal-header">
											 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
											 	<span aria-hidden="true">
											 		<i class="fa fa-close"></i>
											 	</span>
											 </button> 
											<h4 class="modal-title" id="mySmallModalLabel">
												Sign In
											</h4> 
											<form class="sm-frm" style="padding:25px">
												<label>Name :</label>
												<input type="text" class="form-control" placeholder="Enter Email">
												<label>Passoward :</label>
												<input type="text" class="form-control" placeholder="Enter Passoward">
												<label><input type="checkbox" name="personality"> Remenber Me</label>
												<button type="button" class="btn btn-default pull-right">Submit</button>
											</form>
										</div>
									</div>
								</div>
							</div> -->
							
							<!-- large modal -->
							<!-- <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
								<div class="modal-dialog modal-lg" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											 	<span aria-hidden="true">
											 		<i class="fa fa-close"></i>
											 	</span>
											</button>  
											<h4 class="modal-title" id="myLargeModalLabel">Register</h4> 
											<form class="lg-frm" style="padding:25px">
												<label>Name :</label>
												<input type="text" class="form-control" placeholder="Enter Name">
												<label>Email :</label>
												<input type="text" class="form-control" placeholder="Enter Email">
												<label>Passoward :</label>
												<input type="text" class="form-control" placeholder="Enter Passoward">
												<button type="button" class="btn btn-default pull-right">Submit</button>
											</form>
										</div>
									</div>
								</div>
							</div> -->
						</li><!--/li -->
						<li>
							<div class="social-icon">
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								</ul><!--/.ul -->
							</div><!--/.social-icon -->
						</li><!--/li -->
					</ul><!--/ul -->
				</div><!--/.header-right -->
			</div><!--/.container -->	

		</section><!--/.header-->	
		<!--header end-->
		
		<!--menu start-->
		<section id="menu">
			<div class="container">
				<div class="menubar">
					<nav class="navbar navbar-default">
					
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="index.html">
								<h2 style="color: white;">NF Organizer</h2>
							</a>
						</div><!--/.navbar-header -->

						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li class="active"><a href="index.html">Home</a></li>
								<li><a href="#">About</a></li>
								<li><a href="#">Service</a></li>
								<li><a href="#">Project</a></li>
								<!-- <li><a href="team.html">Team</a></li> -->
								<!-- <li><a href="blog.html">Blog</a></li> -->
								<li><a href="#">Contact</a></li>
								<li class="search">
									<form action="">
										<input type="text" name="search" placeholder="Search....">
										<a href="#">
											<span class="lnr lnr-magnifier"></span>
										</a>
									</form>
								</li>
							</ul><!-- / ul -->
						</div><!-- /.navbar-collapse -->
					</nav><!--/nav -->
				</div><!--/.menubar -->
			</div><!-- /.container -->

		</section><!--/#menu-->
		<!--menu end-->
		
		<!-- header-slider-area start -->
		<section class="header-slider-area">
			<div id="carousel-example-generic" class="carousel slide carousel-fade" data-ride="carousel">
			
			  <!-- Indicators -->
				<ol class="carousel-indicators">
					<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
					<li data-target="#carousel-example-generic" data-slide-to="1"></li>
				</ol>

				<!-- Wrapper for slides -->
				<div class="carousel-inner" role="listbox">
					<div class="item active">
						<div class="single-slide-item slide-1">
							<div class="container">
								<div class="row">
									<div class="col-sm-12">
										<div class="single-slide-item-content">
											<h2>NF ORGANIZER</h2>
											<p>
												Memberikan layanan yang memenuhi akan kebutuhan kecepatan, kemudahan, dan kepraktisan untuk mengatasi masalah time efficiency masyarakat perkotaan.
											</p>
											<button type="button" class="slide-btn">
											get started
											</button>
											<button type="button"  class="slide-btn">
												explore more
											</button>
											
										</div><!-- /.single-slide-item-content-->
									</div><!-- /.col-->
								</div><!-- /.row-->
							</div><!-- /.container-->
						</div><!-- /.single-slide-item-->
					</div><!-- /.item .active-->
					<div class="item">
						<div class="single-slide-item slide-2">
							<div class="container">
								<div class="row">
									<div class="col-sm-12">
										<div class="single-slide-item-content">
											<h2>
												NF ORGANIZER</h2>
											<p>
												Memberikan layanan yang memenuhi akan kebutuhan kecepatan, kemudahan, dan kepraktisan untuk mengatasi masalah time efficiency masyarakat perkotaan.
											</p>
											<button type="button"  class="slide-btn">
												get started
											</button>
											<button type="button"  class="slide-btn
											">
												explore more
											</button>
										</div><!-- /.single-slide-item-content-->
									
									</div><!-- /.col-->
								</div><!-- /.row-->
							</div><!-- /.container-->
						</div><!-- /.single-slide-item-->
					</div><!-- /.item .active-->
				</div><!-- /.carousel-inner-->

				<!-- Controls -->
				<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<span class="lnr lnr-chevron-left"></span>
				</a>
				<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<span class="lnr lnr-chevron-right"></span>
				</a>
			</div><!-- /.carousel-->

		</section><!-- /.header-slider-area-->
		<!-- header-slider-area end -->
		
		<!--we-do start -->
		<section  class="we-do">
			<div class="container">
				<div class="we-do-details">
					<div class="section-header text-center">
						<h2>Apa itu NF Organizer?</h2>
						<p>
							NF Organizer adalah event organizer yang memberikan layanan yang memenuhi akan kebutuhan kecepatan, kemudahan, dan kepraktisan untuk mengatasi masalah time efficiency masyarakat perkotaan.
					</div><!--/.section-header-->


		<!--about-us start -->
		<section class="about-us">
			<div class="container">
				<div class="about-us-content">
					<div class="row">
						<div class="col-sm-6">
							<div class="single-about-us">
								<div class="about-us-txt">
									<h2>about us</h2>
									<p>
										NF Organizer adalah sebuah bisnis event organizer yang bergerak di bidang penyedia jasa professional dalam penyelenggaraan acara formal maupunnon formal. Temukan dan bergabung dengan kami.
										</p>
									<div class="project-btn">
										<a href="#"  class="project-view">learn more
										</a>
									</div><!--/.project-btn-->
								</div><!--/.about-us-txt-->
							</div><!--/.single-about-us-->
						</div><!--/.col-->
						<div class="col-sm-6">
							<div class="single-about-us">
								<div class="about-us-img">
									<img src="<?php echo base_url ("assets/images/about/about-part.jpg")?>" alt="about images">
								</div><!--/.about-us-img-->
							</div><!--/.single-about-us-->
						</div><!--/.col-->
					</div><!--/.row-->
				</div><!--/.about-us-content-->
			</div><!--/.container-->

		</section><!--/.about-us-->
		<!--about-us end -->

		<!--service start-->
		<section  class="service">
				<div class="container">
					<div class="service-details">
						<div class="section-header text-center">
							<h2></h2>
							<p></p>
						</div><!--/.section-header-->
						<div class="service-content-one">
									<?php 
										foreach($jns as $jenis){
									?>
										<div class="d-flex">
											<div class="col-sm-4 col-xs-12">	
												<div class="service-single text-center">
													<div class="service-img">
														<img src="<?php echo base_url ("assets/images/service/seminar.jpg")?>" alt="image of service" />
													</div><!--/.service-img-->
													<div class="service-txt">
														<h2>
															<a href=""><?=$jenis->nama?></a>
														</h2>
														<a href="#" class="service-btn">
															learn more
														</a>
													</div>
												</div><!--/.service-single-->
											</div><!--/.col-->
										</div><!--/.row-->
									<?php
										}
									?>
						</div><!--/.service-content-two-->
					</div><!--/.service-details-->
				</div><!--/.container-->

		</section><!--/.service-->
		<!--service end-->

		<!--statistics start-->
		<section  class="statistics">
			<div class="container">
				<div class="statistics-counter "> 
					<div class="col-md-3 col-sm-6">
						<div class="single-ststistics-box">
							<div class="statistics-img">
								<img src="<?php echo base_url ("assets/images/counter/counter1.png")?>" alt="counter-icon" />
							</div><!--/.statistics-img-->
							<div class="statistics-content">
								<div class="counter">2556</div>
								<h3>days worked</h3>
							</div><!--/.statistics-content-->
						</div><!--/.single-ststistics-box-->
					</div><!--/.col-->
					<div class="col-md-3 col-sm-6">
						<div class="single-ststistics-box">
							<div class="statistics-img">
								<img src="<?php echo base_url ("assets/images/counter/counter2.png")?>" alt="counter-icon" />
							</div><!--/.statistics-img-->
							<div class="statistics-content">
								<div class="counter">326</div>
								<h3>project finished</h3>
							</div><!--/.statistics-content-->
						</div><!--/.single-ststistics-box-->
					</div><!--/.col-->
					<div class="col-md-3 col-sm-6">
						<div class="single-ststistics-box">
							<div class="statistics-img">
								<img src="<?php echo base_url ("assets/images/counter/counter3.png")?>" alt="counter-icon" />
							</div><!--/.statistics-img-->
							<div class="statistics-content">
								<div class="counter">1526</div>
								<h3>coffee cup</h3>
							</div><!--/.statistics-content-->
						</div><!--/.single-ststistics-box-->
					</div><!--/.col-->
					<div class="col-md-3 col-sm-6">
						<div class="single-ststistics-box">
							<div class="statistics-img">
								<img src="<?php echo base_url ("assets/images/counter/counter4.png")?>" alt="counter-icon" />
							</div><!--/.statistics-img-->
							<div class="statistics-content">
								<div class="counter">856</div>
								<h3>client satisfied</h3>
							</div><!--/.statistics-content-->
						</div><!--/.single-ststistics-box-->
					</div><!--/.col-->
				</div><!--/.statistics-counter-->	
			</div><!--/.container-->

		</section><!--/.statistics-->
		<!--statistics end-->

		<!--project start-->
		<section id="project"  class="project">
			<div class="container">
				<div class="project-details">
					<div class="project-header text-left">
						<h2>Our Finished Projects</h2>
						<p>
						Beberapa project/event yang telah memakai jasa kami. 
						</p>
					</div><!--/.project-header-->
					<div class="project-content">
						<div class="gallery-content">
							<div class="isotope">
								<div class="row">
									<div class=" col-md-4 col-sm-12">
										<div class="item big-height">
											<img src="<?php echo base_url ("assets/images/project/Seminar.jpg")?>" alt="portfolio image"/>
											<div class="isotope-overlay">
												<a href="project.html">
													<span class="lnr lnr-link"></span>
												</a>
												<h3>
													<a href="#">
														Sukses Kuliah Luar Negeri
													</a>
												</h3>
												<p>Seminar</p>
											</div><!-- /.isotope-overlay -->
										</div><!-- /.item -->
									</div><!-- /.col -->
									<div class="col-md-8 col-sm-12">
										<div class="row">
											<div class="col-sm-6 col-xs-12">
												<div class="item">
													<img src="<?php echo base_url ("assets/images/project/project2.jpg")?>" alt="portfolio image"/>
													<div class="isotope-overlay">
														<a href="#">
															<span class="lnr lnr-link"></span>
														</a>
														<h3>
															<a href="#">
																Penentuan Acara
															</a>
														</h3>
														<p>Open House</p>
													</div><!-- /.isotope-overlay -->
												</div><!-- /.item -->
											</div><!-- /.col -->
											<div class="col-sm-6 col-xs-12">
												<div class="item">
													<img src="<?php echo base_url ("assets/images/project/project3.jpg")?>" alt="portfolio image"/>
													<div class="isotope-overlay">
														<a href="#">
															<span class="lnr lnr-link"></span>
															
														</a>
														<h3>
															<a href="#">
																Kontrak Kerja
															</a>
														</h3>
														<p>Birthday Party</p>
													</div><!-- /.isotope-overlay -->
												</div><!-- /.item -->
											</div><!-- /.col -->
										</div><!-- /.row-->
										<div class="row">
											<div class="col-sm-6 col-xs-12">
												<div class="item">
													<img src="<?php echo base_url ("assets/images/project/workshop.jpg")?>" alt="portfolio image"/>
													<div class="isotope-overlay">
														<a href="#">
															<span class="lnr lnr-link"></span>
															
														</a>
														<h3>
															<a href="#">
																Workshop Marketing
															</a>
														</h3>
														<p>Workshop</p>
													</div><!-- /.isotope-overlay -->
												</div><!-- /.item -->
											</div><!-- /.col -->

										</div><!-- /.row-->

									</div><!-- /.col -->
								</div><!-- /.row -->
								
							</div><!--/.isotope-->
						</div><!--/.gallery-content-->
					</div><!--/.project-content-->
				</div><!--/.project-details-->
				<div class="project-btn text-center">
					<a href="project.html"  class="project-view">view all
					</a>
				</div><!--/.project-btn-->
			</div><!--/.container-->

		</section><!--/.project-->
		<!--project end-->


		<!--team start -->
		<section  class="team">
			<div class="container">
				<div class="team-details">
					<div class="project-header team-header text-left">
						<h2>Our expert team</h2>
						<p> 
						</p>
					</div><!--/.project-header-->
					<div class="team-card">
						<div class="container">
							<div class="row">
								<div class="owl-carousel  team-carousel">
									<div class="col-sm-3 col-xs-12">
										<div class="single-team-box team-box-bg-1">
											<div class="team-box-inner">
												<h3>Budiman Cahyadi</h3>
												<p class="team-meta">Founder &  CEO</p>
												<a href="team.html" class="learn-btn">
													learn more
												</a>
											</div><!--/.team-box-inner-->

										</div><!--/.single-team-box-->
									</div><!--.col-->
									<div class="col-sm-3 col-xs-12">
										<div class="single-team-box team-box-bg-2">
											<div class="team-box-inner">
												<h3>Ardita Mutiarani</h3>
												<p class="team-meta">
													Director, Management & Research
												</p>
												<a href="team.html" class="learn-btn">
													learn more
												</a>
											</div><!--/.team-box-inner-->
										</div><!--/.single-team-box-->
									</div><!--.col-->
									<div class="col-sm-3 col-xs-12">
										<div class="single-team-box team-box-bg-3">
											<div class="team-box-inner">
												<h3>Wulan Syahrani</h3>
												<p class="team-meta">
													Director, Finance Solution
												</p>
												<a href="team.html" class="learn-btn">
													learn more
												</a>
											</div><!--/.team-box-inner-->
										</div><!--/.single-team-box-->
									</div><!--.col-->
									<div class="col-sm-3 col-xs-12">
										<div class="single-team-box team-box-bg-4">	
											<div class="team-box-inner">
												<h3>Devita Ria Wahyuni</h3>
												<p class="team-meta">
													Head, Legal Advising
												</p>
												<a href="team.html" class="learn-btn">
													learn more
												</a>
											</div><!--/.team-box-inner-->
										</div><!--/.single-team-box-->
									</div><!--.col-->
								</div><!--/.team-carousel-->
							</div><!--/.row-->
						</div><!--/.container-->
					</div><!--/.team-card-->
				</div><!--/.team-details-->
			</div><!--/.container-->

		</section><!--/.team-->
		<!--team end-->
	
		<!--pricing start -->
		<section id="pricing" class="pricing">
			<div class="container">
				<div class="pricing-details">
					<div class="section-header text-center">
						<h2 class="price-head">booking </h2>
						<p>
							Dapatkan jasa kami dengan harga spesial
					</div><!--/.section-header-->
					<div class="pricing-content">
						<div class="row">
							<div class="col-md-3 col-sm-6">
								<div class="pricing-box">
									<div class="pricing-header">
										<h2>basic</h2>
										<h3 class="packeg_p"><span>RP</span>2.899.899</h3>
										<p>/event </p>
									</div><!--/.pricing-header-->
									<ul class="plan-lists">
										<li>decorative team</li>
										<li>operational team</li>
										<li>consumption team</li>
									</ul><!--/ul-->
									
									<div class="project-btn pricing-btn text-center">
										<a href="project.html"  class="project-view">
											Sign Up Now
										</a>
									</div><!--/.project-btn-->
								</div><!--/.pricing-box-->
							</div><!--/.col-->

							<div class="col-md-3 col-sm-6">
								<div class="pricing-box">
									<div class="pricing-header">
										<h2>standard</h2>
										<h3 class="packeg_p"><span>RP</span>5.999.999</h3>
										<p>/Event</p>
									</div><!--/.pricing-header-->
									<ul class="plan-lists">
										<li>creative team</li>
										<li>decorative team</li>
										<li>operational team</li>
										<li>consumption team</li>
									</ul><!--/ul-->
									
									<div class="project-btn pricing-btn text-center">
										<a href="project.html"  class="project-view">
											Sign Up Now
										</a>
									</div><!--/.project-btn-->
								</div><!--/.pricing-box-->
							</div><!--/.col-->

							<div class="col-md-3 col-sm-6">
								<div class="pricing-box">
									<div class="pricing-header">
										<h2>advanced</h2>
										<h3 class="packeg_p"><span>RP</span>7.999.000</h3>
										<p>/event</p>
									</div><!--/.pricing-header-->
									<ul class="plan-lists">
										<li>creative team</li>
										<li>decorative team</li>
										<li>operational team</li>
										<li>multimedia team</li>
										<li>consumption team</li>
									</ul><!--/ul-->
									
									<div class="project-btn pricing-btn text-center">
										<a href="project.html"  class="project-view">
											Sign Up Now
										</a>
									</div><!--/.project-btn-->
								</div><!--/.pricing-box-->
							</div><!--/.col-->

							<div class="col-md-3 col-sm-6">
								<div class="pricing-box">
									<div class="pricing-header">
										<h2>unlimited</h2>
										<h3 class="packeg_p"><span>RP</span>10.000.000</h3>
										<p>/Event</p>
									</div><!--/.pricing-header-->
									<ul class="plan-lists">
										<li>creative team</li>
										<li>decorative team</li>
										<li>operational team</li>
										<li>multimedia team</li>
										<li>consumption team</li>
										<li>full support</li>
									</ul><!--/ul-->
									
									<div class="project-btn pricing-btn text-center">
										<a href="project.html"  class="project-view">
											Sign Up Now
										</a>
									</div><!--/.project-btn-->
								</div><!--/.pricing-box-->
							</div><!--/.col-->

						</div><!--/.row-->
					</div><!--/.pricing-content-->
				</div><!--/.pricing-details-->
			</div><!--/.container-->

		</section><!--/.pricing-->
		<!--pricing end-->


		<!-- testemonial Start -->
		<section   class="testemonial">
			<div class="container">
				<div class="section-header text-center">
					<h2>
						<span>
							what our client say about us
						</span>
					</h2>
				</div><!--/.section-header-->
				<div class="owl-carousel owl-theme" id="testemonial-carousel">
					<div class="home1-testm item">
						<div class="home1-testm-single text-center">
							<div class="home1-testm-img">
								<img src="<?php echo base_url ("assets/images/client/testimonial1.jpg")?>" alt="img"/>
							</div><!--/.home1-testm-img-->
							<div class="home1-testm-txt">
								<span class="icon section-icon">
									<i class="fa fa-quote-left" aria-hidden="true"></i>
								</span>
								<p>
									Acara lancar dan berjalan meriah sesuai ekspektasi. terimakasih.
									</p>
								<h3>
									<a href="#">
										kevin watson
									</a>
								</h3>
							</div><!--/.home1-testm-txt-->	
						</div><!--/.home1-testm-single-->
					</div><!--/.item-->
					<div class="home1-testm item">
						<div class="home1-testm-single text-center">
							<div class="home1-testm-img">
								<img src="<?php echo base_url ("assets/images/client/testimonial2.jpg")?>" alt="img"/>
							</div><!--/.home1-testm-img-->
							<div class="home1-testm-txt">
								<span class="icon section-icon">
									<i class="fa fa-quote-left" aria-hidden="true"></i>
								</span>
								<p>
									NF Organizer membantu acara menjadi tersusun dan terorganisir.
								</p>
								<h3>
									<a href="#">
										Sanjaya
									</a>
								</h3>
							</div><!--/.home1-testm-txt-->	
						</div><!--/.home1-testm-single-->
					</div><!--/.item-->
					<div class="home1-testm item">
						<div class="home1-testm-single text-center">
							<div class="home1-testm-img">
								<img src="<?php echo base_url ("assets/images/client/testimonial3.jpg")?>" alt=""/>
							</div><!--/.home1-testm-img-->
							<div class="home1-testm-txt">
								<span class="icon section-icon">
									<i class="fa fa-quote-left" aria-hidden="true"></i>
								</span>
								<p>
									Terimakasih NF ORGANIZER.
								</p>
								<h3>
									<a href="#">
										Mitha
									</a>
								</h3>
							</div><!--/.home1-testm-txt-->	
						</div><!--/.home1-testm-single-->
					</div><!--/.item-->
				</div><!--/.testemonial-carousel-->
			</div><!--/.container-->

		</section><!--/.testimonial-->	
		<!-- testemonial End -->

		</section><!--/news-->
		<!--news end-->

		<!--contact start-->
		<section  class="contact">
			<div class="container">
				<div class="contact-details">
					<div class="section-header contact-head  text-center">
						<h2>contact us</h2>
						<p></p>
					</div><!--/.section-header-->
					<div class="contact-content">
						<div class="row">
							<div class="col-sm-offset-1 col-sm-5">
								<div class="single-contact-box">
									<div class="contact-right">
										<div class="contact-adress">
											<div class="contact-office-address">
												<h3>contact info</h3>
												<p>
													09, Pasirmadang street, Sukajaya, Bogor.
												</p>
												<div class="contact-online-address">
													<div class="single-online-address">
														<i class="fa fa-phone"></i>
														+6285 77722 7672
													</div><!--/.single-online-address-->
													
													<div class="single-online-address">
														<i class="fa fa-envelope-o"></i>
														<span>nforganizer@gmail.com</span>
													</div><!--/.single-online-address-->
												</div><!--/.contact-online-address-->
											</div><!--/.contact-office-address-->
											<div class="contact-office-address">
												<h3>social partner</h3>
												<div class="contact-icon">
													<ul>
														<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li><!--/li-->
														<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li><!--/li-->
														<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li><!--/li-->
														<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li><!--/li-->
													</ul><!--/ul-->
												</div><!--/.contact-icon-->
											</div><!--/.contact-office-address-->
											
										</div><!--/.contact-address-->
									</div><!--/.contact-right-->
								</div><!--/.single-contact-box-->
							</div><!--/.col-->
							<div class="col-sm-5">
								<div class="single-contact-box">
									<div class="contact-form">
										<h3>Leave us a Massage Here</h3>
										<form>
											<div class="row">
												<div class="col-sm-6 col-xs-12">
													<div class="form-group">
													  <input type="text" class="form-control" id="firstname" placeholder="First Name" name="firstname">
													</div><!--/.form-group-->
												</div><!--/.col-->
												<div class="col-sm-6 col-xs-12">
													<div class="form-group">
													  <input type="text" class="form-control" id="lastname" placeholder="Last Name" name="laststname">
													</div><!--/.form-group-->
												</div><!--/.col-->
											</div><!--/.row-->
											<div class="row">
												<div class="col-sm-6 col-xs-12">
													<div class="form-group">
														<input type="email" class="form-control" id="email" placeholder="Email" name="email">
													</div><!--/.form-group-->
												</div><!--/.col-->
												<div class="col-sm-6 col-xs-12">
													<div class="form-group">
														<input type="text" class="form-control" id="phone" placeholder="Phone" name="phone">
													</div><!--/.form-group-->
												</div><!--/.col-->
											</div><!--/.row-->
											<div class="row">
												<div class="col-sm-12">
													<div class="form-group">
														<textarea class="form-control" rows="7" id="comment" placeholder="Message" ></textarea>
													</div><!--/.form-group-->
												</div><!--/.col-->
											</div><!--/.row-->
											<div class="row">
												<div class="col-sm-12">
													<div class="single-contact-btn pull-right">
														<button class="contact-btn" type="button">send message</button>
													</div><!--/.single-single-contact-btn-->
												</div><!--/.col-->
											</div><!--/.row-->
										</form><!--/form-->
									</div><!--/.contact-form-->
								</div><!--/.single-contact-box-->
							</div><!--/.col-->
						</div><!--/.row-->
					</div><!--/.contact-content-->
				</div><!--/.contact-details-->
			</div><!--/.container-->

		</section><!--/.contact-->

		<!-- new-project start -->
		<section  id="new-project" class="new-project">
				<div class="container">
					<div class="new-project-details">
						<div class="row">
							<div class="col-md-10 col-sm-8">
								<div class="single-new-project">
									<h3>
										Want to start a new project with us? Let’s Start!
									</h3>
								</div><!-- /.single-new-project-->	
							</div><!-- /.col-->	
							<div class="col-md-2 col-sm-4">
								<div class="single-new-project">
									<a href="<?php ("form.html")?>" class="slide-btn">
										start now
									</a>
								</div><!-- /.single-new-project-->	
							</div><!-- /.col-->	
						</div><!-- /.row-->	
					</div><!-- /.new-project-details-->	
				</div><!-- /.container-->	

		</section><!-- /.new-project-->	
		<!-- new-project end -->
		
		<!--hm-footer start-->
		<section class="hm-footer">
			<div class="container">
				<div class="hm-footer-details">
					<div class="row">
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="hm-footer-widget">
								<div class="hm-foot-title ">
									<div class="logo">
										<a href="index.html">
											<h2 style="color: white;">NF Organizer</h2>
											<!-- <img src="assets/images/logo/logo.png" alt="logo" /> -->
										</a>
									</div><!-- /.logo-->
								</div><!--/.hm-foot-title-->
								<div class="hm-foot-para">
									<p>
										NF Organizer adalah sebuah bisnis event organizer yang bergerak di bidang penyedia jasa professional dalam penyelenggaraan acara formal maupunnon formal. Temukan dan bergabung dengan kami.
									</p>
								</div><!--/.hm-foot-para-->
								<div class="hm-foot-icon">
									<ul>
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li><!--/li-->
									</ul><!--/ul-->
								</div><!--/.hm-foot-icon-->
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
						<div class=" col-md-2 col-sm-6 col-xs-12">
							<div class="hm-footer-widget">
								<div class="hm-foot-title">
									<h4>Useful Links</h4>
								</div><!--/.hm-foot-title-->
								<div class="footer-menu ">	  
									<ul class="">
										<li><a href="index.html" >Home</a></li>
										<li><a href="about.html">About</a></li>
										<li><a href="service.html">Service</a></li>
										<!-- <li><a href="blog.html">Blog</a></li> -->
										<li><a href="contact.html">Contact us</a></li> 
									</ul>
								</div><!-- /.footer-menu-->
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
						<div class=" col-md-3 col-sm-6 col-xs-12">
							<div class="hm-footer-widget">
								<div class="hm-foot-title">
								</div><!--/.hm-foot-title-->
								<div class="footer-line">
								</div>
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
						<div class=" col-md-3 col-sm-6  col-xs-12">
							<div class="hm-footer-widget">
								<div class="hm-foot-title">
									<h4> Our Newsletter</h4>
								</div><!--/.hm-foot-title-->
								<div class="hm-foot-para">
									<p class="para-news">
										Subscribe to our newsletter to get the latest News and offers..
									</p>
								</div><!--/.hm-foot-para-->
								<div class="hm-foot-email">
									<div class="foot-email-box">
										<input type="text" class="form-control" placeholder="Email Address">
									</div><!--/.foot-email-box-->
									<div class="foot-email-subscribe">
										<button type="button" >go</button>
									</div><!--/.foot-email-icon-->
								</div><!--/.hm-foot-email-->
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
					</div><!--/.row-->
				</div><!--/.hm-footer-details-->
			</div><!--/.container-->

		</section><!--/.hm-footer-details-->
		<!--hm-footer end-->
		
		<!-- footer-copyright start -->
		<footer class="footer-copyright">
			<div class="container">
				<div class="row">
					<div class="col-sm-7">
						<div class="foot-copyright pull-left">
							<p>
								&copy; All Rights Reserved. Designed and Developed by
							 	<a href="https://www.themesine.com">ThemeSINE</a>
							</p>
						</div><!--/.foot-copyright-->
					</div><!--/.col-->
					<div class="col-sm-5">
						<div class="foot-menu pull-right
						">	  
							<ul>
								<li ><a href="#">legal</a></li>
								<li ><a href="#">sitemap</a></li>
								<li ><a href="#">privacy policy</a></li>
							</ul>
						</div><!-- /.foot-menu-->
					</div><!--/.col-->
				</div><!--/.row-->
				<div id="scroll-Top">
					<i class="fa fa-angle-double-up return-to-top" id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div><!--/.scroll-Top-->
			</div><!-- /.container-->

		</footer><!-- /.footer-copyright-->
		<!-- footer-copyright end -->



		<!-- jaquery link -->

		<script src="<?php echo base_url ("assets/js/jquery.js")?>"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        
        <!--modernizr.min.js-->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
		
		
		<!--bootstrap.min.js-->
        <script type="text/javascript" src="<?php echo base_url ("assets/js/bootstrap.min.js")?>"></script>
		
		<!-- bootsnav js -->
		<script src="<?php echo base_url ("assets/js/bootsnav.js")?>"></script>
		
		<!-- for manu -->
		<script src="<?php echo base_url ("assets/js/jquery.hc-sticky.min.js")?>" type="text/javascript"></script>

		
		<!-- vedio player js -->
		<script src="<?php echo base_url ("assets/js/jquery.magnific-popup.min.js")?>"></script>


		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

        <!--owl.carousel.js-->
        <script type="text/javascript" src="<?php echo base_url ("assets/js/owl.carousel.min.js")?>"></script>
		
		<!-- counter js -->
		<script src="<?php echo base_url ("assets/js/jquery.counterup.min.js")?>"></script>
		<script src="<?php echo base_url ("assets/js/waypoints.min.js")?>"></script>
		
        <!--Custom JS-->
        <script type="text/javascript" src="<?php echo base_url ("assets/js/jak-menusearch.js")?>"></script>
        <script type="text/javascript" src="<?php echo base_url ("assets/js/custom.js")?>"></script>
		

    </body>
	
</html>



