<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- META DATA -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		
		

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i,900,900i" rel="stylesheet">
		
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
		
		<link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900" rel="stylesheet">
		
        <!-- TITLE OF SITE -->
        <title>NF Organizer</title>

        <!-- for title img -->
		<link rel="shortcut icon" type="image/icon" href="<?php echo base_url ("assets/images/logo/favicon.png")?>"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/font-awesome.min.css")?>">
		
		<!--linear icon css-->
		<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
		
		<!--animate.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/animate.css")?>">
		
		<!--hover.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/hover-min.css")?>">
		
		<!--vedio player css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/magnific-popup.css")?>">

		<!--owl.carousel.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/owl.carousel.min.css")?>">
		<link href="<?php echo base_url ("assets/css/owl.theme.default.min.css")?>" rel="stylesheet"/>


        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/bootstrap.min.css")?>">
		
		<!-- bootsnav -->
		<link href="<?php echo base_url ("assets/css/bootsnav.css")?>" rel="stylesheet"/>	
        
        <!--style.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/style.css")?>">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="<?php echo base_url ("assets/css/responsive.css")?>">

    </head>
	
	<body>
		<!--header start-->
		<section class="header">
			<div class="container">	
				<div class="header-left">
					<ul class="pull-left">
						<li>
							<a href="#">
								<i class="fa fa-phone" aria-hidden="true"></i> +6285 77722 7672
							</a>
						</li><!--/li-->
						<li>
							<a href="#">
								<i class="fa fa-envelope" aria-hidden="true"></i>nforganizer@gmail.com
							</a>
						</li><!--/li-->
					</ul><!--/ul-->
				</div><!--/.header-left -->
				<div class="header-right pull-right">
					<ul>
						<li class="reg">
							<a href="#" data-toggle="modal" data-target=".bs-example-modal-sm">
								Register
							</a>
								/
							<a href="#" data-toggle="modal" data-target=".bs-example-modal-lg">
								Log in
							</a>
							
							
						</li><!--/li -->
						<li>
							<div class="social-icon">
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								</ul><!--/.ul -->
							</div><!--/.social-icon -->
						</li><!--/li -->
					</ul><!--/ul -->
				</div><!--/.header-right -->
			</div><!--/.container -->	

		</section><!--/.header-->	
		<!--header end-->
		
							<div>
                <table class="table table-striped" style="border: solid;">
                  <thead class="table-success" style="background-color: #7370BD; border:1ch">
                    <tr style="border: solid;">
                      <td>Nomor</td>
                      <td>Nama Kegiatan</td>
                      <td>Kapasitas</td>
                      <td>Harga Ticket</td>
                      <td>Tanggal</td>
                      <td>Narasumber</td>
                      <td>Tempat</td>
                      <td>Pic</td>
                      <td>Jenis Kegiatan</td>
											<td>Action</td>
                    </tr>
                  </thead>
                  <?php
                  $nomor=1;
                  foreach($jen as $obj){
                  ?>
                  <tbody>
                    <tr>
                      <td><?=$nomor?></td>
                      <td><?=$obj->judul?></td>
                      <td><?=$obj->kapasitas?></td>
                      <td><?=$obj->harga_tiket?></td>
                      <td><?=$obj->tanggal?></td>
                      <td><?=$obj->narasumber?></td>
                      <td><?=$obj->tempat?></td>
                      <td><?=$obj->pic?></td>
                      <td><?=$obj->jenis_id?></td>
                      <td>
                        <a href="<?php echo base_url('home/view?id=')?><?=$obj->id?>" class="btn btn-primary btn-sm active">Detail</a>

                        <div>
                        <a href="<?php echo base_url('home/edit?id=')?><?=$obj->id?>" class="btn btn-success btn-sm active">Edit</a>
                        <a href="<?php echo base_url('home/delete?id=')?><?=$obj->id?>" class="btn btn-danger btn-sm active" onclick="if(!confirm('Anda Yakin Hapus<?=$obj->judul?>?')) {return false}">Hapus</a>
                        </div>
											</td>
                    </tr>

                  </tbody>
                </table>
                <?php 
                $nomor++;
                } 
                ?>
							</div>
		
		<!--hm-footer start-->
		<section class="hm-footer">
			<div class="container">
				<div class="hm-footer-details">
					<div class="row">
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="hm-footer-widget">
								<div class="hm-foot-title ">
									<div class="logo">
										<a href="index.html">
											<h2 style="color: white;">NF Organizer</h2>
											<!-- <img src="assets/images/logo/logo.png" alt="logo" /> -->
										</a>
									</div><!-- /.logo-->
								</div><!--/.hm-foot-title-->
								<div class="hm-foot-para">
									<p>
										NF Organizer adalah sebuah bisnis event organizer yang bergerak di bidang penyedia jasa professional dalam penyelenggaraan acara formal maupunnon formal. Temukan dan bergabung dengan kami.
									</p>
								</div><!--/.hm-foot-para-->
								<div class="hm-foot-icon">
									<ul>
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li><!--/li-->
									</ul><!--/ul-->
								</div><!--/.hm-foot-icon-->
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
						<div class=" col-md-2 col-sm-6 col-xs-12">
							<div class="hm-footer-widget">
								<div class="hm-foot-title">
									<h4>Useful Links</h4>
								</div><!--/.hm-foot-title-->
								<div class="footer-menu ">	  
									<ul class="">
										<li><a href="index.html" >Home</a></li>
										<li><a href="about.html">About</a></li>
										<li><a href="service.html">Service</a></li>
										<!-- <li><a href="blog.html">Blog</a></li> -->
										<li><a href="contact.html">Contact us</a></li> 
									</ul>
								</div><!-- /.footer-menu-->
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
						<div class=" col-md-3 col-sm-6 col-xs-12">
							<div class="hm-footer-widget">
								<div class="hm-foot-title">
								</div><!--/.hm-foot-title-->
								<div class="footer-line">
								</div>
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
						<div class=" col-md-3 col-sm-6  col-xs-12">
							<div class="hm-footer-widget">
								<div class="hm-foot-title">
									<h4> Our Newsletter</h4>
								</div><!--/.hm-foot-title-->
								<div class="hm-foot-para">
									<p class="para-news">
										Subscribe to our newsletter to get the latest News and offers..
									</p>
								</div><!--/.hm-foot-para-->
								<div class="hm-foot-email">
									<div class="foot-email-box">
										<input type="text" class="form-control" placeholder="Email Address">
									</div><!--/.foot-email-box-->
									<div class="foot-email-subscribe">
										<button type="button" >go</button>
									</div><!--/.foot-email-icon-->
								</div><!--/.hm-foot-email-->
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
					</div><!--/.row-->
				</div><!--/.hm-footer-details-->
			</div><!--/.container-->

		</section><!--/.hm-footer-details-->
		<!--hm-footer end-->
		
		<!-- footer-copyright start -->
		<footer class="footer-copyright">
			<div class="container">
				<div class="row">
					<div class="col-sm-7">
						<div class="foot-copyright pull-left">
							<p>
								&copy; All Rights Reserved. Designed and Developed by
							 	<a href="https://www.themesine.com">ThemeSINE</a>
							</p>
						</div><!--/.foot-copyright-->
					</div><!--/.col-->
					<div class="col-sm-5">
						<div class="foot-menu pull-right
						">	  
							<ul>
								<li ><a href="#">legal</a></li>
								<li ><a href="#">sitemap</a></li>
								<li ><a href="#">privacy policy</a></li>
							</ul>
						</div><!-- /.foot-menu-->
					</div><!--/.col-->
				</div><!--/.row-->
				<div id="scroll-Top">
					<i class="fa fa-angle-double-up return-to-top" id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div><!--/.scroll-Top-->
			</div><!-- /.container-->

		</footer><!-- /.footer-copyright-->
		<!-- footer-copyright end -->


		<!-- jaquery link -->

		<script src="<?php echo base_url ("assets/js/jquery.js")?>"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        
        <!--modernizr.min.js-->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
		
		
		<!--bootstrap.min.js-->
        <script type="text/javascript" src="<?php echo base_url ("assets/js/bootstrap.min.js")?>"></script>
		
		<!-- bootsnav js -->
		<script src="<?php echo base_url ("assets/js/bootsnav.js")?>"></script>
		
		<!-- for manu -->
		<script src="<?php echo base_url ("assets/js/jquery.hc-sticky.min.js")?>" type="text/javascript"></script>

		
		<!-- vedio player js -->
		<script src="<?php echo base_url ("assets/js/jquery.magnific-popup.min.js")?>"></script>


		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

        <!--owl.carousel.js-->
        <script type="text/javascript" src="<?php echo base_url ("assets/js/owl.carousel.min.js")?>"></script>
		
		<!-- counter js -->
		<script src="<?php echo base_url ("assets/js/jquery.counterup.min.js")?>"></script>
		<script src="<?php echo base_url ("assets/js/waypoints.min.js")?>"></script>
		
        <!--Custom JS-->
        <script type="text/javascript" src="<?php echo base_url ("assets/js/jak-menusearch.js")?>"></script>
        <script type="text/javascript" src="<?php echo base_url ("assets/js/custom.js")?>"></script>
		

    </body>
	
</html>



