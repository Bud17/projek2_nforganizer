<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$this->load->model('v_model', 'jenis');
    $data['jns']=$this->jenis->getAll();

		$this->load->view('home/index', $data);
	}

  public function kegiatan() {
		$this->load->model('kegiatan','acara');
		$jen = $this->acara->getAll();
		$data ['jen'] = $jen;

		$this->load->view('home/kegiatan' , $data);
}

public function view() {
		$id = $this->input->get('id');
$this->load->model('f_models', 'faskes');
$data['rmh'] = $this->faskes->findById($id);

$this->load->view('home/faskes', $data);
}

public function create(){
		$data['faskes']='Form Kelola Rumah Sakit';
		$this->load->view('home/create', $data);
}

public function save(){
		$this->load->model("f_models","faskes");

		$_nama = $this->input->post('nama');
		$_alamat = $this->input->post('alamat');
		$_latlong = $this->input->post('latlong');
		$_jenis_faskes = $this->input->post('jenis');
		$_deskripsi = $this->input->post('deskripsi');
		$_rating = $this->input->post('rating');
		$_kecamatan = $this->input->post('kecamatan');
		$_website = $this->input->post('website');
		$_dokter = $this->input->post('dokter');
		$_pegawai = $this->input->post('pegawai');

		$data_rmh[]=$_nama;
		$data_rmh[]=$_alamat;
		$data_rmh[]=$_latlong;
		$data_rmh[]=$_jenis_faskes;
		$data_rmh[]=$_deskripsi;
		$data_rmh[]=$_rating;
		$data_rmh[]=$_kecamatan;
		$data_rmh[]=$_website;
		$data_rmh[]=$_dokter;
		$data_rmh[]=$_pegawai;

		if(isset($_idedit)){
				$data_rmh[]=$_idedit;
				$this->faskes->update($data_rmh);  
		}else{ 
				$this->faskes->save($data_rmh);   
		} 
		
		redirect(base_url().'index.php/home/jenis?jenis_id='.$_jenis_faskes, 'refresh');

}

public function edit(){
		$id = $this->input->get('id');
		$this->load->model("f_models","faskes");
		$fas = $this->faskes->findById($id);

		$data['faskes']='Form Update Faskes';
		$data['fas']=$fas;
		$this->load->view('home/update',$data);
}

public function delete(){
		$id = $this->input->get('id');
		$this->load->model("f_models","faskes");
		$this->faskes->delete($id);

		redirect(base_url().'index.php/home/jenis', 'refresh');
}
}
